<?php
require_once '../config/database.php'; // Adjust the path based on your project structure

// Database connection
$db = (new Database())->getConnection();

// Admin details
$username = 'admin'; // Change as needed
$password = password_hash('admin123', PASSWORD_BCRYPT); // Use a secure password
$email = 'admin@example.com'; // Change as needed

try {
    $query = "INSERT INTO users (username, password, email) VALUES (:username, :password, :email)";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $password);
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    echo "Admin user created successfully.";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
