<?php
require_once '../config/database.php';
require_once '../src/models/PostModel.php';
require_once '../src/controllers/HomeController.php';

ob_start(); // Start output buffering
session_start(); // Start the session

// Initialize the database and the controllers
$db = (new Database())->getConnection();
$postModel = new PostModel($db);
$homeController = new HomeController($postModel);

// Redirect unauthenticated users to the login page unless they are accessing the login action
if (!isset($_SESSION['user_id']) && (!isset($_GET['action']) || $_GET['action'] !== 'login')) {
    header('Location: ?action=login'); // Redirect to the login page
    exit;
}

// Handle routing logic
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle POST requests
    error_log("POST Request detected");
    if (isset($_POST['post_id'])) {
        error_log("Route: handleCommentSubmission");
        $homeController->handleCommentSubmission();
    } elseif (isset($_POST['username']) && isset($_POST['password'])) {
        error_log("Route: login");
        $homeController->login();
    } elseif (isset($_POST['action']) && $_POST['action'] === 'addPost') {
        error_log("Route: addPost");
        $homeController->addPost();
    }
} elseif (isset($_GET['action'])) {
    // Handle GET requests based on the action parameter
    error_log("GET Request with action: " . $_GET['action']);
    switch ($_GET['action']) {
        case 'login':
            if (isset($_SESSION['user_id'])) {
                // If the user is already logged in, redirect to the admin dashboard
                header('Location: ?action=adminDashboard');
                exit;
            }
            $homeController->login(); // Show the login form
            break;

        case 'viewPost':
            error_log("Route: viewPost");
            $id = $_GET['id'] ?? null;
            $homeController->viewPost($id);
            break;

        case 'addPost':
            error_log("Route: addPost");
            if (!isset($_SESSION['user_id'])) {
                header('Location: ?action=login');
                exit;
            }
            $homeController->addPost();
            break;
            case 'editPost':
                error_log("Route: editPost");
                if (!isset($_SESSION['user_id'])) {
                    header('Location: ?action=login');
                    exit;
                }
                //$homeController->editPost;
                break;
        case 'adminDashboard':
            error_log("Route: adminDashboard");
            if (!isset($_SESSION['user_id'])) {
                header('Location: ?action=login');
                exit;
            }
            $homeController->adminDashboard();
            break;

        case 'logout':
            error_log("Route: logout");
            session_destroy(); // Clear the session
            header('Location: ?action=login'); // Redirect to the login page
            exit;

            case 'manageComments':
                if (!isset($_SESSION['user_id'])) {
                    header('Location: ?action=login');
                    exit;
                }
                $homeController->manageComments();
                break;
            
            case 'manageUsers':
                if (!isset($_SESSION['user_id'])) {
                    header('Location: ?action=login');
                    exit;
                }
                $homeController->manageUsers();
                break;
            
            case 'approveComment':
                if (!isset($_SESSION['user_id'])) {
                    header('Location: ?action=login');
                    exit;
                }
                $homeController->approveComment($_GET['id']);
                break;
            
            case 'deleteComment':
                if (!isset($_SESSION['user_id'])) {
                    header('Location: ?action=login');
                    exit;
                }
                $homeController->deleteComment($_GET['id']);
                break;
            
            case 'deactivateUser':
                if (!isset($_SESSION['user_id'])) {
                    header('Location: ?action=login');
                    exit;
                }
                $homeController->deactivateUser($_GET['id']);
                break;
            
            case 'deleteUser':
                if (!isset($_SESSION['user_id'])) {
                    header('Location: ?action=login');
                    exit;
                }
                $homeController->deleteUser($_GET['id']);
                break;
            

        default:
            error_log("Route: handleNotFound");
            $homeController->handleNotFound();
            break;
    }
} else {
    // Default: Redirect to login if not authenticated; otherwise, show the homepage
    if (!isset($_SESSION['user_id'])) {
        header('Location: ?action=login');
        exit;
    }
    $homeController->index(); // Show the homepage
}
