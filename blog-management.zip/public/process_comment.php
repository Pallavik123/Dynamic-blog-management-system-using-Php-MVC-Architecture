<?php
require_once '../config/database.php';
require_once '../src/models/PostModel.php';

session_start();

// Validate CSRF token
if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    die("Invalid CSRF token.");
}

// Validate input
$postId = filter_input(INPUT_POST, 'post_id', FILTER_VALIDATE_INT);
$author = filter_input(INPUT_POST, 'author', FILTER_SANITIZE_STRING);
$content = filter_input(INPUT_POST, 'content', FILTER_SANITIZE_STRING);

if (!$postId || empty($author) || empty($content)) {
    die("Invalid input data.");
}

// Database connection
$db = (new Database())->getConnection();
$postModel = new PostModel($db);

try {
    // Insert comment into the database
    $query = "INSERT INTO comments (post_id, author, content, status, created_at) 
              VALUES (:postId, :author, :content, 'pending', NOW())";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':postId', $postId, PDO::PARAM_INT);
    $stmt->bindParam(':author', $author, PDO::PARAM_STR);
    $stmt->bindParam(':content', $content, PDO::PARAM_STR);
    $stmt->execute();

    // Redirect back to the single post page
    header("Location: ?action=viewPost&id=$postId&comment=submitted");
    exit;
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
