
<?php
class HomeController
{
    private $postModel;

    public function __construct($postModel)
    {
        $this->postModel = $postModel;
    }

    public function index()
    {
        $limit = 10;
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $offset = ($page - 1) * $limit;

        // Fetch paginated posts
        $posts = $this->postModel->getPaginatedPosts($limit, $offset);

        // Calculate total pages
        $totalPosts = $this->postModel->countPublishedPosts();
        $totalPages = ceil($totalPosts / $limit);

        // Include homepage view with all required variables
        require_once __DIR__ . '/../views/homepage.php';
    }

    public function viewPost($id)
    {
        // Validate the post ID
        if (!is_numeric($id)) {
            echo "Invalid post ID.";
            return;
        }

        // Fetch post details and comments
        $post = $this->postModel->getPostById($id);
        $comments = $this->postModel->getCommentsByPostId($id);

        if (!$post) {
            echo "Post not found.";
            return;
        }

        // Pass data to the view
        require_once __DIR__ . '/../views/single_post.php';
    }

    public function search()
    {
        // Check if search term is provided
        $searchTerm = isset($_GET['q']) ? trim($_GET['q']) : '';

        // If no search term, redirect to homepage
        if (empty($searchTerm)) {
            header("Location: /");
            exit;
        }

        // Fetch search results
        $posts = $this->postModel->searchPosts($searchTerm);

        // Pass data to the search results view
        require_once __DIR__ . '/../views/search_results.php';
    }

    public function handleNotFound()
    {
        echo "Page not found.";
    }

    function generateCsrfToken()
    {
        if (!isset($_SESSION)) {
            session_start();
        }
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    function validateCsrfToken($token)
    {
        if (!isset($_SESSION)) {
            session_start();
        }
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }

    public function login()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
            $password = $_POST['password']; // Raw input for password comparison

            // Check credentials in the database
            $user = $this->postModel->getUserByUsername($username);

            if ($user && password_verify($password, $user['password'])) {
                // Check if the user is active
                if ($user['status'] === 'active') {
                    // Set session variables
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];

                    // Redirect to admin dashboard
                    header('Location: ?action=adminDashboard');
                    exit;
                } else {
                    $error = "Your account is inactive. Please contact the administrator.";
                }
            } else {
                $error = "Invalid username or password.";
            }
        }

        // Show the login page
        require_once __DIR__ . '/../views/login.php';
    }
    public function editPost($id)
    {
        // Check if the request method is POST for form submission
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Sanitize and validate inputs
            $title = filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING);
            $content = filter_input(INPUT_POST, 'content', FILTER_SANITIZE_STRING);
            $image = null;

            // Handle optional image upload
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $uploadDir = __DIR__ . '/../public/uploads/';
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }

                $uploadFile = $uploadDir . basename($_FILES['image']['name']);

                // Validate file type
                $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
                if (!in_array($_FILES['image']['type'], $allowedTypes)) {
                    die("Error: Invalid file type. Only JPG, PNG, and GIF are allowed.");
                }

                // Move the uploaded file
                if (!move_uploaded_file($_FILES['image']['tmp_name'], $uploadFile)) {
                    die("Error: Failed to upload the image.");
                }

                $image = basename($_FILES['image']['name']);
            }

            // Ensure required fields are filled
            if (empty($title) || empty($content)) {
                die("Error: Title and content are required.");
            }

            // Call the model method to update the post
            $result = $this->postModel->updatePost($id, $title, $content, $image);

            if ($result) {
                // Redirect to admin dashboard or confirmation page
                header('Location: ?action=adminDashboard');
                exit;
            } else {
                die("Error: Failed to update the post.");
            }
        }

        // Fetch the post data to pre-fill the form
        $post = $this->postModel->getPostById($id);

        // Render the edit post form
        //$this->view('edit_post', ['post' => $post]);
        require_once __DIR__ . '/../views/edit_post.php';
    }

    public function handleCommentSubmission()
    {
        // Validate CSRF token
        if (!isset($_POST['csrf_token']) || !$this->validateCsrfToken($_POST['csrf_token'])) {
            die("Invalid CSRF token.");
        }

        // Validate and sanitize input
        $postId = filter_input(INPUT_POST, 'post_id', FILTER_VALIDATE_INT);
        $author = filter_input(INPUT_POST, 'author', FILTER_SANITIZE_STRING);
        $content = filter_input(INPUT_POST, 'content', FILTER_SANITIZE_STRING);

        if (!$postId || empty($author) || empty($content)) {
            die("Invalid input data.");
        }

        // Add comment to the database
        $this->postModel->addComment($postId, $author, $content);

        // Redirect back to the single post page
        header("Location: ?action=viewPost&id=$postId&comment=submitted");
        exit;
    }


    public function adminDashboard()
    {
        $posts = $this->postModel->getAllPosts();
        $pendingComments = $this->postModel->getPendingComments();
        $users = $this->postModel->getAllUsers();
        require_once __DIR__ . '/../views/admin_dashboard.php';
    }







    public function addPost()
    {
        error_log("addPost() method called");
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $title = filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING);
            $content = filter_input(INPUT_POST, 'content', FILTER_SANITIZE_STRING);
            $image = null;

            // Validate required inputs
            if (empty($title) || empty($content)) {
                die("Error: Title and content are required.");
            }

            // Handle optional image upload
            if (isset($_FILES['image']) && !empty($_FILES['image']['name'])) {
                $uploadDir = "../public/uploads/";
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }
                $uploadFile = $uploadDir . basename($_FILES['image']['name']);

                // Validate file type
                $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
                if (!in_array($_FILES['image']['type'], $allowedTypes)) {
                    die("Error: Invalid file type. Only JPG, PNG, and GIF are allowed.");
                }

                // Move uploaded file
                if (!move_uploaded_file($_FILES['image']['tmp_name'], $uploadFile)) {
                    die("Error: Failed to upload the image.");
                }

                $image = basename($_FILES['image']['name']);
            }

            // Ensure the user is logged in
            if (!isset($_SESSION['user_id'])) {
                die("Error: User is not logged in.");
            }

            // Add the post to the database
            $result = $this->postModel->addPost($title, $content, $_SESSION['user_id'], $image);
            if (!$result) {
                die("Error: Failed to save post to the database. Check the error log for details.");
            }

            // Redirect to admin dashboard
            header('Location: ?action=adminDashboard');
            exit;
        }

        // Show the "Add Post" form
        require_once __DIR__ . '/../views/add_post.php';
    }



    public function moderateComment($id, $status)
    {
        // Ensure valid status values
        if (!in_array($status, ['approved', 'deleted'])) {
            die("Invalid comment status.");
        }

        $this->postModel->moderateComment($id, $status);

        // Redirect back to the admin dashboard
        header('Location: ?action=adminDashboard');
        exit;
    }

    public function manageComments()
    {
        $comments = $this->postModel->getAllComments();
        require_once __DIR__ . '/../views/manage_comments.php';
    }

    public function manageUsers()
    {
        $users = $this->postModel->getAllUsers();
        require_once __DIR__ . '/../views/manage_users.php';
    }

    public function approveComment($id)
    {
        $this->postModel->updateCommentStatus($id, 'approved');
        header('Location: ?action=manageComments');
        exit;
    }

    public function deleteComment($id)
    {
        $this->postModel->deleteComment($id);
        header('Location: ?action=manageComments');
        exit;
    }

    public function deactivateUser($id)
    {
        $this->postModel->updateUserStatus($id, 'inactive');
        header('Location: ?action=manageUsers');
        exit;
    }

    public function deleteUser($id)
    {
        $this->postModel->deleteUser($id);
        header('Location: ?action=manageUsers');
        exit;
    }
}
