<?php
class PostModel
{
    private $db;

    public function __construct($db)
    {
        $this->db = $db;
    }

    public function getPaginatedPosts($limit, $offset)
    {
        $query = "SELECT * FROM posts WHERE published_at IS NOT NULL ORDER BY published_at DESC LIMIT :limit OFFSET :offset";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function countPublishedPosts()
    {
        $query = "SELECT COUNT(*) AS total FROM posts WHERE published_at IS NOT NULL";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    }

    public function getPostById($id)
    {
        $query = "SELECT * FROM posts WHERE id = :id AND published_at IS NOT NULL";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getCommentsByPostId($postId)
    {
        $query = "SELECT * FROM comments WHERE post_id = :postId AND status = 'approved' ORDER BY created_at DESC";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':postId', $postId, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function searchPosts($searchTerm)
    {
        $query = "SELECT * FROM posts WHERE (title LIKE :searchTerm OR content LIKE :searchTerm) AND published_at IS NOT NULL ORDER BY published_at DESC";
        $stmt = $this->db->prepare($query);
        $likeTerm = '%' . $searchTerm . '%';
        $stmt->bindParam(':searchTerm', $likeTerm, PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // public function addPost($title, $content, $authorId, $image = null)
    // {
    //     $query = "INSERT INTO posts (title, content, author_id, image, created_at) 
    //           VALUES (:title, :content, :authorId, :image, NOW())";
    //     $stmt = $this->db->prepare($query);

    //     // Bind parameters
    //     $stmt->bindParam(':title', $title, PDO::PARAM_STR);
    //     $stmt->bindParam(':content', $content, PDO::PARAM_STR);
    //     $stmt->bindParam(':authorId', $authorId, PDO::PARAM_INT);
    //     $stmt->bindParam(':image', $image, PDO::PARAM_STR);

    //     // Debug query execution
    //     error_log("Debug - Executing query: $query with values Title=$title, Content=$content, AuthorId=$authorId, Image=$image");

    //     if ($stmt->execute()) {
    //         error_log("Debug - Post successfully saved to database.");
    //         return true;
    //     } else {
    //         $errorInfo = $stmt->errorInfo();
    //         error_log("Debug - Database error: " . print_r($errorInfo, true));
    //         die("Error: Database operation failed. " . $errorInfo[2]);
    //     }
    public function addPost($title, $content, $userId, $image = null)
{
    try {
        $sql = "INSERT INTO posts (title, content, author_id, image, published_at)
                VALUES (:title, :content, :author_id, :image, NOW())";

        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':content', $content);
        $stmt->bindParam(':author_id', $userId);
        $stmt->bindParam(':image', $image);

        return $stmt->execute();
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        return false;
    }
    if (!$result) {
        error_log("Database insert failed: " . print_r($this->db->errorInfo(), true));
        die("Error: Failed to save the post to the database.");
    }
    
}

    




    public function updatePost($id, $title, $content, $authorId, $image = null, $publishedAt = null)
    {
        $query = "UPDATE posts SET title = :title, content = :content, author_id = :authorId, image = :image, published_at = :publishedAt, updated_at = NOW() WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':title', $title, PDO::PARAM_STR);
        $stmt->bindParam(':content', $content, PDO::PARAM_STR);
        $stmt->bindParam(':authorId', $authorId, PDO::PARAM_INT);
        $stmt->bindParam(':image', $image, PDO::PARAM_STR);
        $stmt->bindParam(':publishedAt', $publishedAt, PDO::PARAM_STR);
        return $stmt->execute();
    }

    public function deletePost($id)
    {
        $query = "DELETE FROM posts WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        return $stmt->execute();
    }

    public function moderateComment($id, $status)
    {
        $query = "UPDATE comments SET status = :status WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':status', $status, PDO::PARAM_STR);
        $stmt->execute();
    }

    public function getUserByUsername($username)
    {
        $query = "SELECT * FROM users WHERE username = :username LIMIT 1";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':username', $username, PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getAllPosts()
    {
        $query = "
        SELECT posts.id, posts.title, posts.content, posts.published_at, posts.created_at, users.username AS author 
        FROM posts 
        LEFT JOIN users ON posts.author_id = users.id 
        ORDER BY posts.created_at DESC";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }


    public function getPendingComments()
    {
        $query = "SELECT comments.id, comments.content, comments.created_at, posts.title AS post_title 
              FROM comments 
              JOIN posts ON comments.post_id = posts.id 
              WHERE comments.status = 'pending' 
              ORDER BY comments.created_at DESC";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getAllUsers()
    {
        $query = "SELECT id, username, email, status, created_at FROM users ORDER BY created_at DESC";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getAllComments()
    {
        $query = "SELECT comments.id, comments.post_id, comments.author, comments.content, comments.status, comments.created_at
              FROM comments
              ORDER BY created_at DESC";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function updateCommentStatus($id, $status)
    {
        $query = "UPDATE comments SET status = :status WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':status', $status, PDO::PARAM_STR);
        $stmt->execute();
    }

    public function deleteComment($id)
    {
        $query = "DELETE FROM comments WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
    }

    public function updateUserStatus($id, $status)
    {
        $query = "UPDATE users SET status = :status WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':status', $status, PDO::PARAM_STR);
        $stmt->execute();
    }

    public function deleteUser($id)
    {
        $query = "DELETE FROM users WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
    }
}
