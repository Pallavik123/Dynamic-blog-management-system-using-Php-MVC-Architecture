<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-5">
        <h1>Admin Dashboard</h1>

        <!-- Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light mb-4">
            <div class="container-fluid">
                <a class="navbar-brand" href="?action=adminDashboard">Dashboard</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item"><a class="nav-link" href="?action=addPost">Add Post</a></li>
                        <li class="nav-item"><a class="nav-link" href="?action=manageComments">Manage Comments</a></li>
                        <li class="nav-item"><a class="nav-link" href="?action=manageUsers">Manage Users</a></li>
                        <li class="nav-item"><a class="nav-link text-danger" href="?action=logout">Logout</a></li>
                    </ul>
                    <!-- Search Bar -->
                    <form class="d-flex" method="GET" action="?action=search">
                        <input class="form-control me-2" type="search" name="q" placeholder="Search posts..." aria-label="Search">
                        <button class="btn btn-outline-success" type="submit">Search</button>
                    </form>
                </div>
            </div>
        </nav>

        <!-- Blog Posts Management -->
        <h2>Blog Posts</h2>
        <a href="?action=addPost" class="btn btn-success mb-3">Add New Post</a>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Published At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($posts as $post): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($post['id']); ?></td>
                        <td><?php echo htmlspecialchars($post['title']); ?></td>
                        <td><?php echo htmlspecialchars($post['author'] ?? 'Unknown'); ?></td>
                        <td><?php echo htmlspecialchars($post['published_at'] ?? 'Not Published'); ?></td>
                        <td>
                            <a href="?action=editPost&id=<?php echo $post['id']; ?>" class="btn btn-primary btn-sm">Edit</a>
                            <a href="?action=deletePost&id=<?php echo $post['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this post?');">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>

        </table>

        <!-- Comments Management -->
        <h2>Pending Comments</h2>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Post</th>
                    <th>Author</th>
                    <th>Comment</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pendingComments as $comment): ?>
                    <tr>
                        <td><?php echo $comment['id']; ?></td>
                        <td><?php echo htmlspecialchars($comment['post_title']); ?></td>
                        <td><?php echo htmlspecialchars($comment['author']); ?></td>
                        <td><?php echo htmlspecialchars($comment['content']); ?></td>
                        <td>
                            <a href="?action=moderateComment&id=<?php echo $comment['id']; ?>&status=approved" class="btn btn-success btn-sm">Approve</a>
                            <a href="?action=moderateComment&id=<?php echo $comment['id']; ?>&status=deleted" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this comment?');">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Users Management -->
        <h2>Registered Users</h2>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?php echo $user['id']; ?></td>
                        <td><?php echo htmlspecialchars($user['username']); ?></td>
                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                        <td><?php echo $user['status']; ?></td>
                        <td>
                            <a href="?action=deactivateUser&id=<?php echo $user['id']; ?>" class="btn btn-warning btn-sm">Deactivate</a>
                            <a href="?action=deleteUser&id=<?php echo $user['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this user?');">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>

</html>