<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Post</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Edit Blog Post</h1>
        <form method="POST" action="?action=editPost&id=<?php echo $post['id']; ?>" enctype="multipart/form-data" class="form-group">
            <div class="mb-3">
                <label for="title" class="form-label">Title:</label>
                <input type="text" id="title" name="title" class="form-control" value="<?php echo htmlspecialchars($post['title']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="content" class="form-label">Content:</label>
                <textarea id="content" name="content" rows="5" class="form-control" required><?php echo htmlspecialchars($post['content']); ?></textarea>
            </div>
            <div class="mb-3">
                <label for="image" class="form-label">Image (Optional):</label>
                <input type="file" id="image" name="image" class="form-control">
                <?php if (!empty($post['image'])): ?>
                    <p>Current Image: <img src="/public/uploads/<?php echo $post['image']; ?>" alt="Post Image" width="100"></p>
                <?php endif; ?>
            </div>
            
            <button type="submit" class="btn btn-primary">Update Post</button>
        </form>
    </div>
</body>
</html>
